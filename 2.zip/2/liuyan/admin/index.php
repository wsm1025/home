<?php
include 'admin.php';
$page=intval(@$_GET['page']);
if(!$page) $page=1;
$pagesize=10;
$offset=($page-1)*$pagesize;
$res=$db->query("select count(id) from content")->fetch();
$total=$res[0];
$pages=ceil($total/$pagesize);
$res=$db->query("select * from content order by top desc,addtime desc limit $offset,$pagesize")->fetchAll();
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>后台管理</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <script src="../bootstrap/js/jquery.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
</head>

<body>
    <?php include 'head.php';?>
    <div class="container-fluid">
        <div class="col-lg-12 mt-3">
            <table class="table table-bordered">
                <tr>
                    
                    <th>留言内容</th>
                    
                    <th width="120">留言时间</th>
                    <th width="120">留言IP</th>
                    <th width="100">操作</th>
                </tr>
                <?php

foreach($res as $r){
?>
                <tr>
                    
                    <td><?php if($r['top']==1) echo '<span style="color:#F00;">[置顶]</span>';?><?php if($r['verify']!=1) echo '<span style="color:#F00;">[未审核]</span>';?><?php echo $r['content'];?><br><strong>管理回复:</strong><?php echo $r['reply'];?></td>
                    
                    <td><?php echo date('Y-m-d H:i:s',$r['addtime']);?></td>
                    <td><?php echo $r['ip'];?></td>
                    <td>
                        <?php if($r['top']==1){?>
                        <a href="top.php?id=<?php echo $r['id']?>&cancel=1" onclick="return window.confirm('是否取消置顶？')">取消置顶</a><br>
                        <?php }else{ ?>
                        <a href="top.php?id=<?php echo $r['id']?>" onclick="return window.confirm('是否置顶？')">置顶</a><br>
                        <?php }?>
                        <?php if($r['verify']==1){?>
                        <a href="verify.php?id=<?php echo $r['id']?>&cancel=1" onclick="return window.confirm('是否取消审核？')">取消审核</a><br>
                        <?php }else{ ?>
                        <a href="verify.php?id=<?php echo $r['id']?>" onclick="return window.confirm('是否通过审核？')">审核</a><br>
                        <?php }?>
                        <a href="edit.php?id=<?php echo $r['id']?>">修改</a><br>
                        <a href="reply.php?id=<?php echo $r['id']?>">回复</a><br>
                        <a href="del.php?id=<?php echo $r['id'];?>" onclick="return window.confirm('是否删除？')">删除</a>
                    </td>
                </tr>
                <?php
}
?>
            </table>
            
            <nav aria-label="Page navigation ">
                <ul class="pagination" id="pager">
                    <?php
if($page>1){
?>
                    <li class="page-item">
                        <a href="?page=<?php echo $page-1;?>" class="page-link" id="prev">上一页</a>
                    </li>
                    <?php
}
if($pages>$page){
?>
                    <li class="page-item">
                        <a href="?page=<?php echo $page+1;?>" class="page-link" id="next">下一页</a>
                    </li>
                    <?php
}
?>
                </ul>
            </nav>
            
            <div style="height:30px;"></div>
        </div>
    </div>

    
    <script>
        $(function () {

        });
    </script>

</body>

</html>