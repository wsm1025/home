<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">后台管理</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php">留言列表</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="config.php">系统设置</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="password.php">修改密码</a>
      </li>
      <li class="nav-item float-right">
        <a class="nav-link" href="logout.php">安全退出</a>
      </li>
    </ul>

  </div>
</nav>