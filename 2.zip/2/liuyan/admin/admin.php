<?php
include '../function.php';
session_start();

//var_dump($_SESSION['login']);
if($_SESSION['login']!='OK') redir('login.php');