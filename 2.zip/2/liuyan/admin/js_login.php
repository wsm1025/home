<?php
include '../function.php';
session_start();
$name=@$_POST['name'];
$pass=@$_POST['pass'];
$pass=md5($pass);
$data=$db->query("select * from admin where name='$name' and pass='$pass' ")->fetch();

if($data){
    $_SESSION['login']='OK';
    echo 'success';
}